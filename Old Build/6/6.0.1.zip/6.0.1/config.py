bot_token = 'IL_TUO_BOT_TOKEN'
chat_id = 'IL_TUO_CHAT_ID'
autorizzati = [12345678]  # Lista di ID Telegram autorizzati
indirizzi_ping = [
    {'nome': 'Dispositivo1', 'indirizzo': '192.168.1.1'},
    {'nome': 'Dispositivo2', 'indirizzo': '192.168.1.2'},
]
