# status.py
modalita_manutenzione = False
